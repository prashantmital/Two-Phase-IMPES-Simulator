function [ ht ] = hij( i,j )
%HIJ Returns height of cell (i,j)
ht=10;
return;
end

