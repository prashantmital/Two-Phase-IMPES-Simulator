function [ Pc ] = cpress( S1 )
%CPRESS Returns the capillary pressure (least dense-most dense)
Pc = 0;
return;
end

