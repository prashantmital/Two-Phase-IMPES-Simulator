function [ D ] = depth( i,j )
%DEPTH Returns depth of (i,j) cell center from datum
D = 1000;
return;
end

