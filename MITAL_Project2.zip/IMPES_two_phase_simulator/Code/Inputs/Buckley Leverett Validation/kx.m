function [ k ] = kx( i,j )
%KX
k = 2*(10^-12);
return;
end

