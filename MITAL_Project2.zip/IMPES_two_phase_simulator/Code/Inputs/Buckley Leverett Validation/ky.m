function [ k ] = ky( i,j )
%KY 
k = 2*(10^-12);
return;
end

