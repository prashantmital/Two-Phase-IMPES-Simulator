function [ kr2 ] = relperm2( S2 )
%RELPERM2 
kr2 = S2;

end

