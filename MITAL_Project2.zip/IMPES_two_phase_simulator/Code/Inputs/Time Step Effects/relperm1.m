function [ kr1 ] = relperm1( S1 )
%RELPERM1 
kr1 = S1;
end

