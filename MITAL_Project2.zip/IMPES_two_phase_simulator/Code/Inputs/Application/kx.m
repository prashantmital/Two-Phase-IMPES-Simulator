function [ k ] = kx( i,j )
%KX
k = 1.8*(10^-12);
return;
end

