function [ k ] = ky( i,j )
%KY 
k = 1.8*(10^-12);
return;
end

