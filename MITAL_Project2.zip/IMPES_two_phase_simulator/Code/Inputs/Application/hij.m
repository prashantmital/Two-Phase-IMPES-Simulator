function [ ht ] = hij( i,j )
%HIJ Returns height of cell (i,j)
ht=60.96;
return;
end

